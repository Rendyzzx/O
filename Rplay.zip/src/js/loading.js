document.addEventListener("DOMContentLoaded", function() {
  var spinner = document.querySelector(".loading-spinner");
  spinner.style.display = "none";
});