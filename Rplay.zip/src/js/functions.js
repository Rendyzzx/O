function reload() {
  window.location.reload();
}